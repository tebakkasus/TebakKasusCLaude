import { useApp } from "@/context/AppContext";
import { BLOCKS, CASES_DATABASE } from "@/data/cases";

export default function HomeView() {
  const { startGame, setSelectedBlockId, playsToday, isPremium } = useApp();

  const blocksWithQuestions = new Set(
    Object.keys(CASES_DATABASE).filter(
      (k) => CASES_DATABASE[k] && CASES_DATABASE[k].length > 0
    )
  );

  const isBlockAvailable = (id: string) => {
    if (id === "random") return true;
    return blocksWithQuestions.has(id);
  };

  const handleBlockClick = (id: string) => {
    if (!isBlockAvailable(id)) return;
    setSelectedBlockId(id);
    startGame();
  };

  return (
    <div className="space-y-5">
      <div className="text-center pt-2 pb-1">
        <h1 className="text-2xl font-extrabold text-slate-800 leading-tight">
          Kuasai Diagnosis Klinis
        </h1>
        <p className="mt-2 text-sm text-slate-500 max-w-xs mx-auto">
          Pilih blok spesialisasi dan jawab skenario pasien bertahap untuk
          persiapan UKMPPD.
        </p>
        {!isPremium && (
          <p className="mt-2 text-xs text-blue-500 font-medium">
            {5 - playsToday > 0
              ? `${5 - playsToday} soal gratis tersisa hari ini`
              : "Limit harian tercapai — upgrade untuk lanjut"}
          </p>
        )}
      </div>

      <div className="grid grid-cols-2 gap-3">
        {BLOCKS.map((block) => {
          const available = isBlockAvailable(block.id);
          const questionCount =
            block.id === "random"
              ? Object.values(CASES_DATABASE).reduce((a, b) => a + b.length, 0)
              : (CASES_DATABASE[block.id]?.length ?? 0);

          return (
            <button
              key={block.id}
              onClick={() => handleBlockClick(block.id)}
              disabled={!available}
              className={[
                "flex items-center gap-3 p-3.5 rounded-xl border-2 text-left transition-all active:scale-[0.97]",
                available
                  ? "bg-white border-slate-200 hover:border-blue-400 hover:bg-blue-50/60 cursor-pointer"
                  : "bg-slate-50 border-slate-100 opacity-40 cursor-not-allowed",
              ].join(" ")}
            >
              <span className="text-2xl leading-none flex-shrink-0">
                {block.icon}
              </span>
              <div className="min-w-0">
                <p className="text-sm font-semibold text-slate-700 leading-tight">
                  {block.name}
                </p>
                {available && block.id !== "random" && (
                  <p className="text-xs text-slate-400 mt-0.5">
                    {questionCount} soal
                  </p>
                )}
                {block.id === "random" && (
                  <p className="text-xs text-slate-400 mt-0.5">
                    {questionCount} soal campuran
                  </p>
                )}
              </div>
            </button>
          );
        })}
      </div>

      <p className="text-center text-xs text-slate-400 pb-2">
        Klik blok untuk langsung mulai
      </p>
    </div>
  );
}
